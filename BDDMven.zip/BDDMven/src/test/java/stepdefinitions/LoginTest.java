package stepdefinitions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class LoginTest {

    WebDriver driver ;


    @Given("when the user is on sauce lab demo login page")
    public void when_the_user_is_on_sauce_lab_demo_login_page() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");

    }
    @When("the user enters valid {string} and {string}")
    public void theUserEntersValidAnd(String arg0, String arg1) {
        driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys(arg0);
        driver.findElement(By.xpath("//input[@id='password']")).sendKeys(arg1);

    }
    @When("clicks on login button")
    public void clicks_on_login_button() {
        driver.findElement(By.xpath("//input[@id='login-button']")).click();
    }
    @Then("user should be successfully logged")
    public void user_should_be_successfully_logged() {
        String currentURL = driver.getCurrentUrl();
        String expectedUrl = "https://www.saucedemo.com/inventory.html";
        Assert.assertEquals(currentURL, expectedUrl);

    }


}
