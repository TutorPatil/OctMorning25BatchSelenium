package stepdefinitions;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LoginTest {

    WebDriver driver ;


    @Given("when the user is on sauce lab demo login page")
    public void when_the_user_is_on_sauce_lab_demo_login_page() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");

    }
    @When("the user enters valid {string} and {string}")
    public void theUserEntersValidAnd(String arg0, String arg1) {
        driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys(arg0);
        driver.findElement(By.xpath("//input[@id='password']")).sendKeys(arg1);

    }
    @When("clicks on login button")
    public void clicks_on_login_button() {
        driver.findElement(By.xpath("//input[@id='login-button']")).click();
    }

    @Then("user should be successfully logged")
    public void user_should_be_successfully_logged() {
        String currentURL = driver.getCurrentUrl();
        String expectedUrl = "https://www.saucedemo.com/inventory.html";
        Assert.assertEquals(currentURL, expectedUrl);

    }

    @When("the user attempts these credentials:")
    public void theUserAttemptsTheseCredentials(DataTable table) throws InterruptedException {
        List<Map<String, String>> rows = table.asMaps(String.class, String.class);

        for (Map<String, String> row : rows) {
            String username = row.get("username");
            String password = row.get("password");
            String expect = row.getOrDefault("expect", "success");

            // fill fields
            driver.findElement(By.id("user-name")).clear();
            driver.findElement(By.id("user-name")).sendKeys(username);
            driver.findElement(By.id("password")).clear();
            driver.findElement(By.id("password")).sendKeys(password);

            // submit
            driver.findElement(By.id("login-button")).click();
            Thread.sleep(2000);

            // simple success check: inventory page URL present (null-safe)
            String currentUrl = driver.getCurrentUrl();
            boolean success = currentUrl != null && currentUrl.contains("/inventory.html");

            if ("success".equalsIgnoreCase(expect)) {
                Assert.assertTrue(success, "Expected login to succeed for user: " + username);
                driver.get("https://www.saucedemo.com/");
            } else {
                // For failure rows, ensure user did not reach inventory page
                Assert.assertFalse(success, "Expected login to fail for user: " + username);
                driver.get("https://www.saucedemo.com/");
            }
        }
    }

    public static void main(String[] args) {

        Map<String,String> m = new HashMap<>();

        m.put("Ramu","Bengalore");
        m.put("Shamu","Hyderabad");
        m.put("Radha","Delhi");

    List<String> al = new ArrayList<>();

        al.add("Student1");
        al.add("Student2");
        al.add("Student3");





    }

}
