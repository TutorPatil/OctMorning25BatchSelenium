package com.saucelab.dataproviders;

import org.testng.annotations.DataProvider;

public class DataProviders {

    @DataProvider(name = "logindata")
    public  Object[][] supplyLoginData()
    {
        Object[][] x = new Object[3][3];

        x[0][0] = "standard_user";
        x[0][1] = "secret_sauce";
        x[0][2] = 20;


        x[1][0] = "standard_user";
        x[1][1] = "secret_sauce";
        x[1][2] = 25;

        x[2][0] = "visual_user";
        x[2][1] = "secret_sauce";
        x[2][2] = 30;

        return  x;
    }



}
