package com.saucelab.tests;

import com.saucelab.base.BaseClass;

import java.io.IOException;

public class TestRunner extends BaseClass {

    public static void main(String[] args) throws Exception {

        //LoginTests.login_001();
        //CartTests.addItemToCart_001();


    }
}
