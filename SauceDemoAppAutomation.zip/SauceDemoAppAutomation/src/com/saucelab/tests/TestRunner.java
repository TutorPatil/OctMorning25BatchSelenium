package com.saucelab.tests;

import com.saucelab.base.BaseClass;

import java.io.IOException;

public class TestRunner extends BaseClass {

    public static void main(String[] args) throws IOException {

        LoginTests.login_001();


    }
}
