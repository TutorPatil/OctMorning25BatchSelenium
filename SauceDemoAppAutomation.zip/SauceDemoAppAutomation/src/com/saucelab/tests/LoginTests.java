package com.saucelab.tests;

import com.saucelab.base.BaseClass;
import com.saucelab.utils.CommonUtils;

import java.io.IOException;

public class LoginTests extends BaseClass {





    public static void login_001() throws IOException {

        writeLogsToFile("*****  starting the test case Login_001*****");
        launchApplication();
        boolean result = CommonUtils.loginToSaucelabApp();

        writeLogsToFile("**** launched the app now trying to login*****");
        if(result) {
            writeLogsToFile("**** successfully logged in to the app*****");
            writeResultsToFile("login_001", "Pass");
            captureScreenShot("login_001");
        }
        else {
            writeLogsToFile("**** could not login to the app*****");
            writeResultsToFile("login_001", "Fail!");
            captureScreenShot("login_001");
        }
        closeBrowser();
        writeLogsToFile("*****  ending the test case Login_001*****");


    }
}
