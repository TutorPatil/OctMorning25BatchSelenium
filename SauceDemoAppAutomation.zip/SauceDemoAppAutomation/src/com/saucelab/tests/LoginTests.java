package com.saucelab.tests;

import com.saucelab.base.BaseClass;
import com.saucelab.utils.CommonUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.io.IOException;
import java.util.PrimitiveIterator;

public class LoginTests extends BaseClass {

   //@Test(priority = 1)
   // @Test(groups = { "smoke", "login","login_001" })
   // @Parameters({ "username", "password" })
   //@Test(groups = { "smoke", "login","login_001" })

    //@Test
    //@Parameters({ "username", "password" })
    //@Test(dataProvider = "test1")
    //@Test(groups = { "smoke", "login","login_001" },dataProvider = "logindata" )  // if the data provider is in the same class of test
    //@Test(groups = { "smoke", "login","login_001" },dataProvider = "logindata" , dataProviderClass = com.saucelab.dataproviders.DataProviders.class)
    @Test(groups = { "smoke", "login","login_001" },dataProvider = "logindata" , dataProviderClass = com.saucelab.dataproviders.DataProviders.class)
    public static void login_001(String userNameValue, String passwordValue,Integer x) throws Exception {

        System.out.println(userNameValue);
        System.out.println(passwordValue);
        System.out.println(x);

        //int age = Integer.parseInt(x);

        boolean result = CommonUtils.loginToSaucelabApp(userNameValue, passwordValue);

        //Assert.assertTrue(result);
        Assert.assertTrue(result,"Could not login to saucelab app!!");
        captureScreenShot("login_001");

    }

    //@Test(priority = 2)
    //@Test(enabled = false) // This method will not be picked by TestNG
    //@Test(dependsOnMethods = "login_001") // This will run only of login_001 is pass else it will be skipped
    @Test(groups = { "regression", "login" ,"login_002"},dependsOnMethods = "login_003")

    public static void login_002() throws Exception {

        writeLogsToFile("*****  starting the test case login_002*****");
        boolean result = CommonUtils.loginToSaucelabApp();
        writeLogsToFile("**** launched the app now trying to login*****");

        //Assert.assertTrue(result);
        Assert.assertTrue(result,"Could not login to saucelab app!!");
        writeLogsToFile("**** successfully logged in to the app*****");
        writeResultsToFile("login_002", "Pass");
        captureScreenShot("login_002");
        writeLogsToFile("*****  ending the test case login_002*****");
    }

    @Test(groups = { "regression", "login" ,"login_003"})
    public static void login_003() throws Exception {


        boolean result = CommonUtils.loginToSaucelabApp();

        SoftAssert sAssert = new SoftAssert();


        //Assert.assertTrue(result);
        //Assert.assertFalse(result,"Could not login to saucelab app!!");
        sAssert.assertFalse(result,"Could not login to saucelab app!!");

        int expectedCount = 5;
        int actualCount = 5;

        sAssert.assertEquals(expectedCount,actualCount," The numbers does not match...");

        sAssert.assertEquals(expectedCount,10,"The numbers does not macth...");

        sAssert.assertAll();

        //Assert.assertEquals(expectedCount,actualCount,"Both the numbers does not match");

        writeResultsToFile("login_002", "Pass");
        captureScreenShot("login_002");
        writeLogsToFile("*****  ending the test case login_002*****");
    }

/*
    // Data Provider in the same class of Test
    @DataProvider(name = "logindata")
    public static Object[][] supplyLoginData()
    {
        Object[][] x = new Object[3][3];

        x[0][0] = "standard_user";
        x[0][1] = "secret_sauce";
        x[0][2] = 30; // integer data


        x[1][0] = "standard_user";
        x[1][1] = "secret_sauce";

        x[2][0] = "visual_user";
        x[2][1] = "secret_sauce";

        return  x;
    }

 */
}
