package com.saucelab.tests;

import com.saucelab.base.BaseClass;
import com.saucelab.utils.CommonUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Payment extends BaseClass {

    @Test(groups = { "regression", "payment","payment_001" })
    public static void payment_001() throws Exception {

        writeLogsToFile("*****  starting the test case payment_001*****");
        boolean result = CommonUtils.loginToSaucelabApp();

        writeLogsToFile("**** launched the app now trying to login*****");

        Assert.assertTrue(result, "Payment not successful!!");
        writeLogsToFile("**** successfully logged in to the app*****");
        writeResultsToFile("payment_001", "Pass");
        captureScreenShot("payment_001");

        writeLogsToFile("*****  ending the test case payment_001*****");


    }

}
