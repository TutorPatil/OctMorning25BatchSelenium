package com.saucelab.tests;

import com.saucelab.base.BaseClass;

public class ProfileTests extends BaseClass {
}
