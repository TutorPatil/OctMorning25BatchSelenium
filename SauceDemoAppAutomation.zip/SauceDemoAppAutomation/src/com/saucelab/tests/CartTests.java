package com.saucelab.tests;

import com.saucelab.base.BaseClass;
import com.saucelab.utils.CommonUtils;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

public class CartTests extends BaseClass {

    @Test(groups = { "smoke", "cart" ,"addItemToCart_001"})
    public static void addItemToCart_001()  throws Exception{
        boolean result = false;

        CommonUtils.loginToSaucelabApp();
        driver.findElement(By.xpath(getLocatorData("backpackAddButton"))).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath(getLocatorData("cartIcon"))).click();
        Thread.sleep(2000);

        result = driver.findElement(By.xpath(getLocatorData("cartItemAdded"))).isDisplayed();

        Assert.assertTrue(result , "could not add the item to the cart!!");
        writeLogsToFile("**** successfully added the item to cart*****");
        writeResultsToFile("addItemToCart_001", "Pass");

    }
        }






