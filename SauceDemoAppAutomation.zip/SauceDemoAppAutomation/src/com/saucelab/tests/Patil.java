package com.saucelab.tests;


import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.saucelab.base.BaseClass;

import org.openqa.selenium.By;

import java.io.*;

public class Patil extends BaseClass {



    public static void main(String[] args) throws IOException {

        String loc = getLocatorDataFomJason("LoginPage","username");
        System.out.println(loc);

        launchApplication();
        File f = new File("./src/tools/selenium.png");
        String filePath = f.getAbsolutePath();
        driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
        driver.findElement(By.id("picture")).sendKeys(filePath);

    }

    public static String getLocatorDataFomJason(String pageName, String elementName) throws FileNotFoundException {
        String locator = "";
        Reader reader = new FileReader(new File("./src/data/locatordatafile.json"));
        JsonObject jsonObject = JsonParser.parseReader(reader).getAsJsonObject();
        locator = jsonObject.get(pageName).getAsJsonObject().get(elementName).getAsString();
        return locator;

    }




    }

