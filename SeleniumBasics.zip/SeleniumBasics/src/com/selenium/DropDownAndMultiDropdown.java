package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class DropDownAndMultiDropdown {

    static WebDriver driver = null;

    public static void main(String[] args) throws InterruptedException {


    }


    public static void handlingMultiSelectList() throws InterruptedException {
        launchBrowser("file:///C:/Users/Sudhanva/Desktop/SaagTrainings/Selenium/DayWiseCode/FIrst2Sessions/Login.html");

        // Create the webelement for identifying the dropdown
        WebElement dropDown =driver.findElement(By.xpath("//select[@id='cars']"));

        // Create the object of select and pass the webelemt as constructor argument.
        Select comboSelect = new Select(dropDown);

        Boolean isMulti = comboSelect.isMultiple();

        System.out.println("isMulti: " + isMulti);

        comboSelect.selectByVisibleText("Saab");
        Thread.sleep(2000);
        comboSelect.selectByVisibleText("Audi");
        Thread.sleep(2000);
        comboSelect.selectByVisibleText("Opel");
        Thread.sleep(2000);
        comboSelect.deselectByVisibleText("Audi");

        List<WebElement> selectedItems =  comboSelect.getAllSelectedOptions();
        System.out.println(selectedItems.size());
        selectedItems.forEach(n -> System.out.println(n.getText()));

    }

    public static void handlingDropDownBox() throws InterruptedException {
        launchBrowser("file:///C:/Users/Sudhanva/Desktop/SaagTrainings/Selenium/DayWiseCode/FIrst2Sessions/Login.html");

        // Create the webelement for identifying the dropdown
        WebElement dropDown =driver.findElement(By.xpath("//select[@id='country']"));

        // Create the object of select and pass the webelemt as constructor argument.
        Select comboSelect = new Select(dropDown);

        comboSelect.selectByVisibleText("England");
        Thread.sleep(3000);
        comboSelect.selectByIndex(0);
        Thread.sleep(3000);
        comboSelect.selectByValue("USA");

        String item =comboSelect.getFirstSelectedOption().getText();
        System.out.println(item);

        List<WebElement> items = comboSelect.getOptions();

        System.out.println(items.size());
        items.forEach(n -> System.out.println(n.getText()));

//        for(int x=0; x<items.size(); x++){
//            System.out.println(items.get(x).getText());
//        }


    }



    public static void getTextExample()
    {
        launchAndLoginSauceDemoApp("https://saucedemo.com/","locked_out_user","secret_sauce");

        String errorText = driver.findElement(By.xpath("//h3")).getText();
        System.out.println(errorText);
    }






    public static void launchAndLoginSauceDemoApp(String url,String userNameData, String passwordData)
    {
        launchBrowser(url);
        driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys(userNameData);
        driver.findElement(By.xpath("//input[@id='password']")).sendKeys(passwordData);
        driver.findElement(By.xpath("//input[@id='login-button']")).click();

    }


    public static void launchBrowser(String url)
    {
        driver = new ChromeDriver();
        driver.get(url);
    }




}
