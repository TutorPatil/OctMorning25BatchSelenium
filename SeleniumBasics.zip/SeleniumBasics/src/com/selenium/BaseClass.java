package com.selenium;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class BaseClass {

    public static WebDriver driver = null;

    public static void launchBrowser(String url) throws IOException {

        String browser = getConfigData("browser");

        if (browser.equalsIgnoreCase("chrome")) {
            driver = new ChromeDriver();
        }
        if (browser.equalsIgnoreCase("firefox")) {
            driver = new FirefoxDriver();
        }
        if (browser.equalsIgnoreCase("edge")) {
            driver = new EdgeDriver();
        }

        driver.get(url);
    }

    public static String getConfigData(String key) throws IOException {
            String propVal = "";

            File f = new File("./src/data/configdata.properties");
            FileInputStream fio = new FileInputStream(f);

            // Creating the object of properties file
            Properties prop = new Properties();

            // using the load method of properties class to load the input stream
            prop.load(fio);

           // to get  the property value based on key
           propVal = prop.getProperty(key);
           return propVal;

    }


    public static String getLocatorData(String locatorName) throws IOException {
        String locatorValue = "";

        File f = new File("./src/data/locatordata.properties");
        FileInputStream fio = new FileInputStream(f);

        // Creating the object of properties file
        Properties prop = new Properties();

        // using the load method of properties class to load the input stream
        prop.load(fio);

        // to get  the property value based on key
        locatorValue = prop.getProperty(locatorName);
        return locatorValue;

    }

    public static String getTestData(String keyName) throws IOException {
        String Value = "";

        File f = new File("./src/data/testdata.properties");
        FileInputStream fio = new FileInputStream(f);

        // Creating the object of properties file
        Properties prop = new Properties();

        // using the load method of properties class to load the input stream
        prop.load(fio);

        // to get  the property value based on key
        Value = prop.getProperty(keyName);
        return Value;

    }

    public static By getElement(String element) throws IOException {

         By b =  By.xpath(getLocatorData(element));
         return b;
    }

    public static WebElement getWebElement(String element) throws IOException {
       WebElement webelement = driver.findElement(getElement(element));
       return webelement;
    }


    public static void captureScreenShot(String fileName) throws IOException {


        // Down casting driver to Take Screenshot level and capturng screen shot as file
        File source = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

        // Creating a file class object to save the screen shot as a file
        File dest = new File("./src/screenshots/"+fileName+".png");

        // Copying src to destination ,, this will create the physical file in the destination location
        FileHandler.copy(source, dest);


    }


}
