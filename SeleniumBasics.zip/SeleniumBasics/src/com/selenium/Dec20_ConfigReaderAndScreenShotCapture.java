package com.selenium;

import org.openqa.selenium.By;

import java.io.IOException;

public class Dec20_ConfigReaderAndScreenShotCapture extends BaseClass{


    public static void main(String[] args) throws IOException {

        // Fetching the confidata for URL
        String url = getConfigData("url");

        // Launching the browser using the launch browser method coming from base class
        launchBrowser(url);

        // get locatordata and get test data methods are coming from baseclass
        //driver.findElement(By.xpath("//input[@id='username']")).sendKeys("standardUser");
        driver.findElement(By.
                xpath(getLocatorData("usernameTextbox"))).sendKeys(getTestData("usernameData"));
        //driver.findElement(By.xpath(getLocatorData("passwordTextbox"))).sendKeys(getTestData("passwordData"));
        driver.findElement(getElement("passwordTextbox")).sendKeys(getTestData("passwordData"));

        //driver.findElement(By.xpath("//input[@id='login-button']")).click();
        //driver.findElement(By.xpath(getLocatorData("loginButton"))).click();
        // getWebElement method is coming from base class.
        getWebElement("loginbutton").click();


//        getWebElement("usernameTextbox").sendKeys(getTestData("usernameData"));
//        getWebElement("passwordTextbox").sendKeys(getTestData("passwordData"));
//        getWebElement("loginbutton").click();



        // Capturing screen shot of a page as a png file
        captureScreenShot("sauceDemoscreenshot");

        // closing the browser at the end..
        driver.quit();
//


    }




}
