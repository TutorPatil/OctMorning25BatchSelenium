package com.saucelab.utils;

import com.saucelab.base.BaseClass;

public class PaymentUtils extends BaseClass {
}
