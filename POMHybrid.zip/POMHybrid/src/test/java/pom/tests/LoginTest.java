package pom.tests;

import org.testng.annotations.Test;
import pom.base.BaseTest;
import pom.pages.LoginPage;

public class LoginTest extends BaseTest {

    @Test(groups = { "smoke", "login","login_001" })
    public void login_001() {
        LoginPage loginPage = new LoginPage(driver);

        // getting the test data from jsonFile
        String userName = getTestDataFromJson("loginpage","usernameData");
        String password = getTestDataFromJson("loginpage","passwordData");

        loginPage.login(userName, password);
    }

    // This test case is using the data from data provider, the Data provider reads data from Excel
    @Test(groups = { "smoke", "login","login_002" },dataProvider = "logindata" , dataProviderClass = pom.dataproviders.DataProvider.class)
    public void login_002(String userName, String password) {
        LoginPage loginPage = new LoginPage(driver);

        // getting the test data using data provider
        loginPage.login(userName, password);
    }


}
