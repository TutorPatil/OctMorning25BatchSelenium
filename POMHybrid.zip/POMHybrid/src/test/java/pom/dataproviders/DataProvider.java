package pom.dataproviders;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;

public class DataProvider {

    @org.testng.annotations.DataProvider(name = "logindata")
    public  Object[][] supplyLoginData() throws Exception {
        Object[][] x = new Object[3][2];
        File f = new File("./src/test/data/testdata.xlsx");
        FileInputStream fis = new FileInputStream(f);
        XSSFWorkbook wb =  new XSSFWorkbook(fis);
        XSSFSheet ws = wb.getSheetAt(0);

        for(int i=1;i<=3;i++) {
            for(int j=0;j<=1;j++) {
                x[i-1][j] =ws.getRow(i).getCell(j).getStringCellValue();
            }
        }
        return  x;
    }
}
