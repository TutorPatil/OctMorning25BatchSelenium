package com.saucelab.tests;

import com.saucelab.pages.LoginPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class LoginTests {

    @Test
    public static void login_001(){

        WebDriver driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/");

        LoginPage login = new LoginPage( driver );
        login.enterUserName("standard_user");
        login.enterPassword("secret_sauce");
        login.clickLoginButton();
    }
}
