package com.saucelab.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

    WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);

    }

    @FindBy(xpath = "//input[@id='user-name']")
    private WebElement userNameTextBox;

    @FindBy(id = "password")
    private WebElement passwordTextBox;

    @FindBy(xpath =  "//input[@id='login-button']")
    private WebElement loginButton;

    public  void enterUserName(String usernameData){
        userNameTextBox.sendKeys(usernameData);
    }

    public void enterPassword(String passwordData){
        passwordTextBox.sendKeys(passwordData);
    }

    public void clickLoginButton()
    {
        loginButton.click();
    }





}
