package com.saucelab.pages;

public class BasePage {



}
